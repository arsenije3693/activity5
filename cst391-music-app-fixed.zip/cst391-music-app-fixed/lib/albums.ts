export type Album = {
  id: number;
  title: string;
  artist: string;
  year: number;
  createdAt: string;
};

let nextId = 3;

export let albums: Album[] = [
  {
    id: 1,
    title: "Debug Album One",
    artist: "Professor Sparks",
    year: 2024,
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    title: "Debug Album Two",
    artist: "Arsenije Brajovic",
    year: 2025,
    createdAt: new Date().toISOString()
  }
];

export function addAlbum(data: { title: string; artist: string; year: number }): Album {
  const album: Album = {
    id: nextId++,
    title: data.title,
    artist: data.artist,
    year: data.year,
    createdAt: new Date().toISOString()
  };
  albums = [...albums, album];
  return album;
}
