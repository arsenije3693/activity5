import AlbumList from "./components/AlbumList";

export default function HomePage() {
  return (
    <div>
      <AlbumList />
    </div>
  );
}
