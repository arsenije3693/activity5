import { NextResponse } from "next/server";
import { albums, addAlbum } from "@/lib/albums";

export async function GET() {
  return NextResponse.json(albums);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, artist, year } = body;

    if (!title || !artist) {
      return NextResponse.json(
        { error: "Title and artist are required." },
        { status: 400 }
      );
    }

    const parsedYear = Number(year) || new Date().getFullYear();
    const album = addAlbum({ title, artist, year: parsedYear });

    return NextResponse.json(album, { status: 201 });
  } catch (err) {
    console.error("Error in POST /api/albums", err);
    return NextResponse.json(
      { error: "Failed to create album" },
      { status: 500 }
    );
  }
}
