import "./globals.css";
import type { ReactNode } from "react";
import NavBar from "./components/NavBar";

export const metadata = {
  title: "Sparks Music App – Arsenije Brajovic",
  description: "CST-391 Music App Debug View"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <NavBar />
        <main>{children}</main>
      </body>
    </html>
  );
}
